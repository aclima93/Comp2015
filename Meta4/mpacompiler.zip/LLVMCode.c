


#include "LLVMCode.h"


void printLLVM(node* ast_root){

	printLLVMHeader();

	printLLVMCode(ast_root);
}

void printLLVMHeader(){

	// helper functions
    printf("declare i32 @printf(i8*, ...)\n");
    printf("declare i32 @atoi(i8*) nounwind readonly\n");
    printf("\n");

	// global variables used for printing values 
	// --- booleans "TRUE" and "FALSE"
	// --- integer and real literals
    printf("@str.int_lit = private unnamed_addr constant [i32] c\"%%d\\0A\\00\"\n");
    printf("@str.real_lit = private unnamed_addr constant [double] c\"%%.12E\\0A\\00\"\n");
    printf("@str.false = private unnamed_addr constant [7 x i8] c\"FALSE\\0A\\00\"\n");
    printf("@str.true = private unnamed_addr constant [7 x i8] c\"TRUE\\0A\\00\\00\"\n");
    printf("@str.bools = global [2 x i8*] [i8* getelementptr inbounds ([7 x i8]* @str.false, i32 0, i32 0), i8* getelementptr inbounds ([7 x i8]* @str.true, i32 0, i32 0)]\n");
    printf("\n");
}

void printChildrenLLVMCode(node* cur_node){

	printLLVMCode(cur_node->field1);
	printLLVMCode(cur_node->field2);
	printLLVMCode(cur_node->field3);

}

void printLLVMCode(node* cur_node){

	if( cur_node == NULL ){
		return;
	}

	NodeType t = cur_node->type_of_node;

	switch(t) {

		case ProgType:
			
			printChildren(cur_node);
			break;

		case VarDeclarationType:
		case FuncPartType:
		case FuncDeclarationType:
		case FuncDefinitionType:
		case FuncDefinition2Type:
		case ParamsType:
		case VarPartType:
		case VarParamsType:


			printf("%s\n", getIndependantStr(t) );

			printChildren(cur_node);
			break;

		case FuncHeadingType:

			// print nothing, intermediate node
			// don't even increment dot counter

			printChildren(cur_node);
			break;

		case FuncParamsListType:

			printChildren(cur_node);
			break;

		case ProgBlockType:
		case FuncIdentType:
		case FuncBlockType:
		case StatType:

			// print nothing, intermediate node
			// don't even increment dot counter

			printChildren(cur_node);

			break;

		case IfElseStatType:

			printf("%s\n", getStatStr(t));

			printChildren(cur_node);
			break;

		case RepeatStatType:
		case WhileStatType:
		case ValParamStatType:
		case AssignStatType:
		case WriteLnStatType:

			;
			char* stat_str = getStatStr(t);

			if( stat_str != NULL ){
				printf("%s\n", stat_str);
			}

			printChildren(cur_node);
			break;

		case ExprType:
		case SimpleExprType:
		case FactorType:
		case OPTermListType: 

			// the operator is always printed first
			// don't call printChildren !!

			printChildrenMiddleFirst(cur_node);

			break;

		case StatListType:
			
			printChildren(cur_node);
			break;


		case FuncParamsListType2:
		case FuncDeclarationListType:
		case VarDeclarationListType:
		case IDListType:
		case CommaIDListType:
		case CompStatType:
		case WritelnPListType:
		case ParamListType:
		case ExprListType:

			// print nothing, intermediate node
			// don't even increment dot counter
			// all members are the same "depth"

			printChildren(cur_node);

			break;

		case DoubleType:
		case IntType:
		case IDType:
		case StringType:

			printf("%s(%s)\n", getLeafStr(t), cur_node->field1 );
			break;

		case CallType:

			printf("Id(%s)\n", (char*) cur_node->field1);
			break;

		case UnaryOPType:

			getUnaryOPStr(cur_node->field1);
			break;

		case OPType:
		
			getOPStr(cur_node->field1);
			break;

		default:
			break;
	}

}

/* Counter printing functions */
char* printCurVar() {
    char* str = (char*) malloc(sizeof(int));
    sprintf(str, "%%%d", varCounter);
    return str;
}

char* printCurLocalVar() {
    char* str = (char*) malloc(sizeof(int));
    sprintf(str, "%%%d", localVarCounter);
    return str;
}

char* printCurLabelCounter() {
    char* str = (char*) malloc(sizeof(int));
    sprintf(str, ".label%d", labelCounter);
    return str;
}

char* printCurReturnLabel() {
    char* str = (char*) malloc(sizeof(int));
    sprintf(str, ".return%d", returnLabelCounter);
    return str;
}





