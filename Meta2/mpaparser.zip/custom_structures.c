
#include "custom_structures.h"

node* makenode(nodeType t, node* f1, node* f2, node* f3){
	return NULL;
}

node* makeleafInt(int i){
	return NULL;
}

node* makeleafString(char* s){
	return NULL;
}

node* makeleafDouble(double d){
	return NULL;
}